require("dotenv").config();

module.exports = {
    token: process.env.TOKEN || "",
    clientID: process.env.CLIENT_ID || "1365718201899548855", 
    prefix: process.env.PREFIX || "&", 
    ownerID: process.env.OWNER_ID || "711106072118689834",
    guildID: process.env.GUILD_ID || "1358433004745265163",
    SpotifyID: process.env.SPOTIFY_ID || "aece5b4d7d27426ebef592a75bd43a2c",
    SpotifySecret: process.env.SPOTIFY_SECRET || "79a8a54525324e9aa3291eeb880ff287",
    mongourl: process.env.MONGO_URL || "",
    embedColor: process.env.EMBED_COLOR || 0xcc0000,
    logs: process.env.LOGS || "1365584276745093190",
    logs1: process.env.LOGS1 || "1365584276745093190",
    errorLogsChannel: process.env.ERROR_LOGS_CHANNEL || "1365584276745093190",
    buglogschannel: process.env.BUG_LOGS_CHANNEL || "1365584276745093190",
    SearchPlatform: "youtube",
    AggregatedSearchOrder: process.env.AGGREGATED_SEARCH_ORDER ||"youtube ,youtube music,youtube,soundcloud",
    links: {
        img: process.env.IMG || 'https://cdn.discordapp.com/attachments/1365612916740456458/1365613022286184458/standard.gif?ex=681337bc&is=6811e63c&hm=807b74bb5e1e5329a098d7d3d5487cd12111a30c36e01e631788d41c91fc00fd&', 
        support: process.env.SUPPORT || 'https://discord.gg/7ynwY33SC5',
        invite: process.env.INVITE || 'https://discord.com/api/oauth2/authorize?client_id=1365718201899548855&permissions=36768832&scope=applications.commands%20bot' 
    },
    nodes: [
           {
            host: process.env.NODE_HOST || "85.88.163.80",
            port: parseInt(process.env.NODE_PORT || "3128"),
            password: process.env.NODE_PASSWORD || "saher.inzeworld.com",
            secure: parseBoolean(process.env.NODE_SECURE || "false"),
            }
           ],

}

function parseBoolean(value) {
    if (typeof (value) === 'string') {
        value = value.trim().toLowerCase();
    }
    switch (value) {
        case true:
        case "true":
            return true;
        default:
            return false;
    }
}



/*
 * Modified By Gamer CodeX
 * Discord username - ray.dev
 * Youtube - https://www.youtube.com/@GamerCodeX
 * Discord Server - https://dsc.gg/codexdev
 */